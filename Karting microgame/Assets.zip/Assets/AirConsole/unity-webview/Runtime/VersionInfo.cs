public class VersionInfo
{
    public const string VERSION = "1.0.1";
}